<?php

    //array("filter_cat", "image", prod_id, price, "name")
    $home_products = array (
        array("women", "product-1.jpg", 1, 10, "Product 1"),
        array("women", "product-2.jpg", 2, 20, "Product 2"),
        array("men", "product-3.jpg", 3, 30, "Product 3"),
        array("children", "product-4.jpg", 4, 40, "Product 4"),
        array("men", "product-5.jpg", 5, 50, "Product 5"),
        array("shoes", "product-6.jpg", 6, 60, "Product 6")
    );

    $cart_list = $_SESSION["cart"];
?>