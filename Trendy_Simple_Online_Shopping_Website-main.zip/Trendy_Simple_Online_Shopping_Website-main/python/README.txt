##############################################################
! Important
##############################################################

- Update the .env path variables. Else image search won't work properly.

- Install the application requirements using the following command
    $ pip install -r requirements.txt

- Run the application after installing the requirements using the following command
    $ python app.py

    

##############################################################
! Optional
##############################################################

- Create Virtualenv to run the application.
