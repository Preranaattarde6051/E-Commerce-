<?php
	$dbServerName = "localhost";
	$dbUserName = "root";
	$dbPassword ="";
	$dbName = "bb_store";

	$con = mysqli_connect($dbServerName,$dbUserName,$dbPassword,$dbName);

?>